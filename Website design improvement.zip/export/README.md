# BurkeBuild — v2 redesign (drop-in)

Static, no build step. Everything here maps 1:1 onto your existing `site/` folder.

## Install
Unzip and copy the contents over your `site/` directory, replacing:

- `index.html`
- `404.html`
- `css/styles.css`
- `js/main.js`
- `projects/contemporary-rear-extension.html`
- `projects/double-height-kitchen-extension.html`
- `sitemap.xml`, `robots.txt`
- `assets/` (unchanged image set — safe to skip if yours already match)

## Part M removed
This redesign drops the Part M offering entirely. After copying, delete the old page:

    site/projects/part-m-home-adaptation.html

(Its FAQ entry, JSON-LD schema, sitemap entry and nav/ticker references are already stripped from the new files.)

## What changed
- New cinematic hero, tactile card system (cursor glow + tilt), magnetic buttons
- Auto-scrolling / drag-and-flick service & process strips
- Scroll-reveal animations, custom dropdown, project filters
- All interactions are vanilla JS in `js/main.js` — no dependencies, respects `prefers-reduced-motion`

## Notes
- Images use `.jpg`. If you want to reintroduce your `<picture>` + AVIF setup for performance, the `.avif` files are still in your original `assets/`.
- Fonts load from Google Fonts (Archivo, Archivo Expanded, Inter).
